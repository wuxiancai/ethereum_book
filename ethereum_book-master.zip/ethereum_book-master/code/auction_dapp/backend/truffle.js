module.exports = {
  networks: {
    development: {
      host: "52.59.238.144",
      port: 8545,
      network_id: "*",
      gas: 3000000
    }
  }
};
